<?php
include_once FILE_CHUA . '/model/Order.php';
class OrderController
{


    public function gioHang()
    {

        if ($_SERVER["REQUEST_METHOD"] == "GET") {
            $id = $_GET['id'];

            $obj = new Order();
            $getId = $obj->get_order($id);
            // unset($_SESSION['sanpham']);
            // die();

            $_SESSION['sanpham'][$id] = $getId;
            // echo '<pre>';
            // print_r($_SESSION['sanpham']);
            // die();


            include FILE_CHUA . '/view/order/giohang.php';
        }
    }

    public function xemGioHang()
    {
        $gioHang = $_SESSION['sanpham'];
        if (!isset($gioHang)) {
            echo 'Chưa có sản phẩm nào';
        } else {
            include FILE_CHUA . '/view/order/xemgiohang.php';
        }
    }
    public function muaHang()
    {

        if ($_SERVER["REQUEST_METHOD"] == "GET") {
            $id = $_GET['id'];
            $obj = new Order();
            $getId = $obj->get_order($id);

            include FILE_CHUA . '/view/order/muahang.php';
        }
    }
    public function thanhToan(){
        include FILE_CHUA . '/view/order/thanhtoan.php';
    }
}

<?php include FILE_CHUA . '/view/admin_layout/header.php'; ?>
<div id="layoutSidenav">
    <?php include FILE_CHUA . '/view/admin_layout/menu.php'; ?>

</div>
<div class="card-body">
    <!-- Giao diện ở giữa -->
    <img style=" width: 100%;height: 100%;" src="https://img2.thuthuatphanmem.vn/uploads/2018/12/09/anh-dep-hacker-chat_111113828.jpg" alt="">
</div>


<?php include FILE_CHUA . '/view/admin_layout/footer.php'; ?>
<style>
  img {
    display: block;
    margin-left: auto;
    margin-right: auto;
  }

  h3 {
    color: red;
  }
</style>
<section class="slider_section ">
  <div class="slider_bg_box">
    <img src="https://media.thethao247.vn/upload/hiep95/2019/01/15/binh-chon-7-mau-thiet-ke-vinfast-premium-nhan-vinfast-fadil1547552173.jpeg" alt="">
  </div>

</section>